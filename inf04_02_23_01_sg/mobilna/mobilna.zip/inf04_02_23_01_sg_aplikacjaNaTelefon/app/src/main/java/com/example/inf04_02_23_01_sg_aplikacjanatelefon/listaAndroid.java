package com.example.inf04_02_23_01_sg_aplikacjanatelefon;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class listaAndroid extends AppCompatActivity {

    private EditText poleEdycyjne;
    private Button przycisk;
    private ListView lista;
    private ArrayList listaElementow = new ArrayList();
    private ArrayAdapter adapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.listandroid);

        poleEdycyjne = findViewById(R.id.poleEdycyjne);
        przycisk = findViewById(R.id.przycisk);
        lista = findViewById(R.id.lista);

        listaElementow.add("Zakupy: chleb,masło,ser");
        listaElementow.add("Do zrobienia: objad,umyć podłogi");
        listaElementow.add("weekend: kino,spacer z psem");

        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listaElementow);
        lista.setAdapter(adapter);

        przycisk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Editable wartoscPoleEdycyjne = poleEdycyjne.getText();
                listaElementow.add(wartoscPoleEdycyjne);
                adapter.notifyDataSetChanged();

            }
        });

    }
}
