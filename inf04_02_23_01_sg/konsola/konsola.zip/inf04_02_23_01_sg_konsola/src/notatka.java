/**
 * klasa: notatka
 * opis: klasa służy do tworzenia notatek, zawiera ona funkcje wypisywania tytułu oraz treści notatki jak i funkcję diagnostyczną
 * pola: licznikNotatek - przechowuje ona liczbe utworzonych notatek
 *       identyfikator - nadaje unikalne id każdej notatce
 *       tytul - przechowuje tytuł notatki
 *       tresc - przechowuje treść notatki
 * autor: 00000000000
 */
public class notatka {

    private static int licznikNotatek;
    private int identyfikator;
    protected String tytul;
    protected String tresc;

    public notatka(String tytul, String tresc) {
        this.tytul = tytul;
        this.tresc = tresc;

        licznikNotatek++;

        identyfikator = licznikNotatek;

    }

    public void tytulITrescNotatki(){

        System.out.println(tytul);
        System.out.println(tresc);

    }

    public void diagnostyka(){

        System.out.println(licznikNotatek+";"+identyfikator+";"+tytul+";"+tresc);

    }

    public static void main(String[] args) {

        notatka notka1 = new notatka("Kurs java","Ta notatka zawiera najważniejsze informacje z książki o kursie java");

        notka1.tytulITrescNotatki();
        notka1.diagnostyka();

        notatka notka2 = new notatka("Dokumatacja na tak","Notka z najważniejszymi aspektami potrzebnymi do tworzenia dokumentacji");

        notka2.tytulITrescNotatki();
        notka2.diagnostyka();

    }

}
