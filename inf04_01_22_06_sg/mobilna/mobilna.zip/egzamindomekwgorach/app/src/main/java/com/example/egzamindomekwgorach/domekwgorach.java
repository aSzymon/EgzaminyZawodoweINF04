package com.example.egzamindomekwgorach;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class domekwgorach extends AppCompatActivity {

    private Button polub;
    private Button usun;
    private TextView polubienia;

    private int licznik = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.layoutapk);

        polub = findViewById(R.id.polub);
        usun = findViewById(R.id.usun);
        polubienia = findViewById(R.id.polubienia);

        polub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                licznik++;
                polubienia.setText(licznik+" polubień");

            }
        });

        usun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                licznik--;
                polubienia.setText(licznik+" polubień");

                if (licznik <= 0){

                    licznik = 1;

                }

            }
        });

    }
}
