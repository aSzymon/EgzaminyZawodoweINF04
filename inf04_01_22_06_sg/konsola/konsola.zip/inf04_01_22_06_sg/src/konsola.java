import java.util.Random;
import java.util.Scanner;

public class konsola {

    Random random = new Random();

    public int[] getTablicaElementow() {
        return tablicaElementow;
    }

    int tablicaElementow[] = new int[50];
    int znalezionyIndex;

    public void losowanie(int wartownik){

        tablicaElementow = new int[tablicaElementow.length+1];

        for (int i = 0; i < tablicaElementow.length; i++){

            tablicaElementow[i] = random.nextInt(100);

        }

        tablicaElementow[tablicaElementow.length - 1] = wartownik;

        System.out.println("");

    }

    /**
     * nazwa funkcji: przeszukiwanie
     * argumenty: wartownik - przechowuje wartosc do wyszukiwania
     *            poczatkowaWartoscWartownika - przechowuje początkową wartość nadaną wartownikowi (wartownik - wartowsc do wyszukania)
     * typ zwracany: brak
     * informacje: funkcja ta służy do sprawdzania czy liczba podana jako wartownik znajduje się w tablicy
     * autor: 00000000000
     */
    public void przeszukiwanie(int wartownik,int poczatkowaWartoscWartownika){

        for (int i = 0; i < getTablicaElementow().length-1; i++){

            if (getTablicaElementow()[i] == wartownik){

                znalezionyIndex = i;
                System.out.println("wartownik został odnaleziony, znajduje się pod indexem "+i);
                wartownik = -1;

            }

        }

        if (wartownik == poczatkowaWartoscWartownika){

            System.out.println("nie odnaleziono wartownika");

        }

    }

    public static void main(String[] args) {

        Scanner skan = new Scanner(System.in);

        konsola konsola = new konsola();

            System.out.print("Podaj wartownik > ");
            int wartownik = skan.nextInt();

            konsola.losowanie(wartownik);

            for (int j = 0; j < konsola.getTablicaElementow().length-1; j++){

                System.out.print(konsola.getTablicaElementow()[j]+", ");

            }

        System.out.println("");

        int poczatkowaWartoscWartownika = wartownik;

        konsola.przeszukiwanie(wartownik,poczatkowaWartoscWartownika);


        }

    }

