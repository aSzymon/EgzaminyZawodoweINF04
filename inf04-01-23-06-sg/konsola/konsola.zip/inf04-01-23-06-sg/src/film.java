/**
 * nazwa klasy: film
 * pola: tytul - przechowuje tytul filmu
 *       wyporzyczenia - przechowuje liczbe wyporzyczen filmu
 * metody: setTytul, nic nie zwraca, ustawia tytul filmu
 *         getTytul, zwraca tytul, pobiera wartosc z pod zmiennej tytul
 *         getWyporzyczenia, zwraca liczbe wyporzyczen, pobiera liczbe wyporzyczen filmu
 * informacje: klasa odpowiada za nadawanie filmowi tytułu oraz sprawdzanie ile osób wyporzyczyło film
 * autor: 00000000000
 */
public class film {

    protected String tytul;
    protected int wyporzyczenia;

    public film(){

        this.tytul = "";
        this.wyporzyczenia = 0;

    }

    public void setTytul(String tytul) {
        this.tytul = tytul;
    }

    public String getTytul() {
        return tytul;
    }

    public int getWyporzyczenia() {
        return wyporzyczenia;
    }

    public void inkrementacja(){

        wyporzyczenia++;

    }

    public static void main(String[] args) {

        film film = new film();

        film.setTytul("Jakiś tytuł");

        System.out.println(film.getTytul());

        System.out.println(film.getWyporzyczenia());

        film.inkrementacja();

        System.out.println(film.getWyporzyczenia());

    }

}
