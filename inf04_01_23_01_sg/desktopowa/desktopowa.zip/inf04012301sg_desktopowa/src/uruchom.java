public class uruchom {

    public static void main(String[] args) {

        new aplickaja();

    }

}
