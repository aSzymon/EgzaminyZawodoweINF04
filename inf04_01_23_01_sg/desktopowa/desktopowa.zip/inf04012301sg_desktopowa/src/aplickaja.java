import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class aplickaja {

    String haslo;

    public JPanel createConcentPane(){

        JPanel okno = new JPanel();

        JPanel danePracownika = new JPanel(null);
        danePracownika.setBounds(50,50,350,270);
        danePracownika.setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE, 4), "Dane Pracownika", TitledBorder.LEFT, TitledBorder.TOP, new Font("Arial", Font.ROMAN_BASELINE, 14)
        ));
        danePracownika.setBackground(new Color(176, 196, 222));
        danePracownika.setVisible(true);
        okno.add(danePracownika);

        JLabel imie = new JLabel("Imię");
        imie.setBounds(30,30,100,30);
        imie.setFont(new Font("Arial",Font.ROMAN_BASELINE,16));
        imie.setVisible(true);
        danePracownika.add(imie);

        JTextArea imiePole = new JTextArea();
        imiePole.setBounds(170,30,150,30);
        imiePole.setFont(new Font("Arial", Font.BOLD,16));
        imiePole.setVisible(true);
        danePracownika.add(imiePole);

        JLabel nazwisko = new JLabel("Nazwisko");
        nazwisko.setBounds(30,90,100,30);
        nazwisko.setFont(new Font("Arial",Font.ROMAN_BASELINE,16));
        nazwisko.setVisible(true);
        danePracownika.add(nazwisko);

        JTextArea nazwiskoPole = new JTextArea();
        nazwiskoPole.setBounds(170,90,150,30);
        nazwiskoPole.setFont(new Font("Arial", Font.BOLD,16));
        nazwiskoPole.setVisible(true);
        danePracownika.add(nazwiskoPole);

        JLabel stanowisko = new JLabel("Stanowisko");
        stanowisko.setBounds(30,150,100,30);
        stanowisko.setFont(new Font("Arial",Font.ROMAN_BASELINE,14));
        stanowisko.setVisible(true);
        danePracownika.add(stanowisko);

        JComboBox stanowiskoLista = new JComboBox();
        stanowiskoLista.setBounds(170,150,150,30);
        stanowiskoLista.setVisible(true);

        stanowiskoLista.addItem("");
        stanowiskoLista.addItem("Kierownik");
        stanowiskoLista.addItem("Starszy programista");
        stanowiskoLista.addItem("Młodszy programista");
        stanowiskoLista.addItem("Tester");

        danePracownika.add(stanowiskoLista);

        JPanel generowanieHasla = new JPanel(null);
        generowanieHasla.setBounds(500,50,350,270);
        generowanieHasla.setBorder(BorderFactory.createTitledBorder(new LineBorder(Color.WHITE,4),"Generowanie hasła",TitledBorder.LEFT,TitledBorder.TOP,new Font("Arial",Font.ROMAN_BASELINE,16)));
        generowanieHasla.setBackground(new Color(176, 196, 222));
        generowanieHasla.setVisible(true);
        okno.add(generowanieHasla);

        JLabel ileZnakow = new JLabel("Ile znaków?");
        ileZnakow.setBounds(30,30,100,30);
        ileZnakow.setFont(new Font("Arial",Font.ROMAN_BASELINE,16));
        ileZnakow.setVisible(true);
        generowanieHasla.add(ileZnakow);

        JTextArea ileZnakowPole = new JTextArea();
        ileZnakowPole.setBounds(170,30,150,30);
        ileZnakowPole.setFont(new Font("Arial", Font.BOLD,16));
        ileZnakowPole.setVisible(true);
        generowanieHasla.add(ileZnakowPole);

        JCheckBox maleIWielkieLitery = new JCheckBox("Małe i wielkie litery",true);
        maleIWielkieLitery.setBounds(30,80,300,30);
        maleIWielkieLitery.setFont(new Font("Arial",Font.ROMAN_BASELINE,16));
        maleIWielkieLitery.setVisible(true);
        generowanieHasla.add(maleIWielkieLitery);

        JCheckBox cyfry = new JCheckBox("Cyfry");
        cyfry.setBounds(30,120,300,30);
        cyfry.setFont(new Font("Arial",Font.ROMAN_BASELINE,16));
        cyfry.setVisible(true);
        generowanieHasla.add(cyfry);

        JCheckBox znakiSpecjalne = new JCheckBox("Znaki specjalne");
        znakiSpecjalne.setBounds(30,160,300,30);
        znakiSpecjalne.setFont(new Font("Arial",Font.ROMAN_BASELINE,16));
        znakiSpecjalne.setVisible(true);
        generowanieHasla.add(znakiSpecjalne);

        JButton generujHaslo = new JButton("Generuj hasło");
        generujHaslo.setBounds(115,210,140,30);
        generujHaslo.setForeground(Color.WHITE);
        generujHaslo.setBackground(new Color(70, 130, 180));
        generujHaslo.setVisible(true);
        generowanieHasla.add(generujHaslo);

        generujHaslo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String iloscZnakow = ileZnakowPole.getText();
                boolean literyWartosc = maleIWielkieLitery.isSelected();
                boolean cyfryWartosc = cyfry.isSelected();
                boolean znakiWartosc = znakiSpecjalne.isSelected();

                dzialanie dzialanie = new dzialanie();
                haslo = dzialanie.generujHaslo(iloscZnakow,literyWartosc,cyfryWartosc,znakiWartosc);

                JOptionPane.showMessageDialog(null,haslo,"Wygenerowane hasło",JOptionPane.INFORMATION_MESSAGE);

            }
        });

        JButton zatwierdz = new JButton("Zatwierdź");
        zatwierdz.setBounds(310,340,270,30);
        zatwierdz.setBackground(new Color(70, 130, 180));
        zatwierdz.setForeground(Color.white);
        zatwierdz.setVisible(true);
        okno.add(zatwierdz);

        zatwierdz.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String imieWartosc = imiePole.getText();
                String nazwiskoWartosc = nazwiskoPole.getText();
                String listaWartosc = String.valueOf(stanowiskoLista.getSelectedItem());

                JOptionPane.showMessageDialog(null,""+imieWartosc+" "+nazwiskoWartosc+" "+listaWartosc+" "+haslo);

            }
        });

        return okno;

    }

    public aplickaja(){

        JFrame frame = new JFrame("Dodaj pracownika | 00000000000");
        frame.setContentPane(createConcentPane());
        frame.setLayout(null);
        frame.setSize(910,420);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.getContentPane().setBackground(new Color(176, 196, 222));
        frame.setDefaultCloseOperation(2);
        frame.setVisible(true);

    }
}
