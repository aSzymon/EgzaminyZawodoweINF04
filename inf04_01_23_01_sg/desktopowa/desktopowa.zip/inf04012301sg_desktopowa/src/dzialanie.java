import java.util.Random;

public class dzialanie {

    Random rand = new Random();

    String pulaZnakow = "qwertyuiopasdfghjklzxcvbnm";
    String haslo = "";

    public String generujHaslo(String ileZnakow,Boolean litery,Boolean cyfry,Boolean znaki){

    if (litery == true){

        pulaZnakow = pulaZnakow.concat("QWERTYUIOPASDFGHJKLZXCVBNM");

    }

    if (cyfry == true){

        pulaZnakow = pulaZnakow.concat("12345567890");

    }

    if (znaki == true){

        pulaZnakow = pulaZnakow.concat("!@#$%^&*()_+-=");

    }

    int wartoscIleZnakow = Integer.parseInt(ileZnakow);

    for (int i = 0; i < wartoscIleZnakow; i++){

        char wylosowanyZnak =  pulaZnakow.charAt(rand.nextInt(pulaZnakow.length()));
        haslo = haslo.concat(String.valueOf(wylosowanyZnak));

    }

        return haslo;

    }

}
