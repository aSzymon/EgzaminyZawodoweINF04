import java.util.Scanner;

public class konsola {

    /**
     * nazwa funkcji: algorytmEuklidesa
     * opis funkcji: funkcja sluzy do szukania najwiekszego wspolnego dzielnika z dwoch liczb
     * parametry: a - pierwsza podana liczba do algorytmu
     *            b - druga podana liczba do algorytmu
     * zwracany typ i opis: brak zwracanej wartosciS
     * autor: 00000000000
     */
    public void algorytmEuklidesa(int a,int b){

        while (a != b){

            if (a > b){
                a = a - b;
            } else {
                b = b - a;
            }

        }
        System.out.println(a);

    }

    public static void main(String[] args) {

        Scanner skan = new Scanner(System.in);

        System.out.print("Podaj liczbe a > ");
        int a = skan.nextInt();

        System.out.print("Podaj liczbe b > ");
        int b = skan.nextInt();

        konsola algorytm = new konsola();

        algorytm.algorytmEuklidesa(a,b);

    }

}

