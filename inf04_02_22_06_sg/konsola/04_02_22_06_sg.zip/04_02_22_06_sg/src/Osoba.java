import java.util.Scanner;

public class Osoba {

    private int id;
    private String imieOsoby;
    static int instancje;

    public Osoba() {
        this.id = 0;
        this.imieOsoby = "";

        instancje++;
    }

    public Osoba(int id, String imieOsoby) {
        this.id = id;
        this.imieOsoby = imieOsoby;

        instancje++;
    }

    public Osoba(Osoba osoba) {
        this.id = osoba.id;
        this.imieOsoby = osoba.imieOsoby;

        instancje++;
    }

    public void wypisywanieImienia(String imie){

        if (imie.length() == 0){

            System.out.println("Cześć Brak danych, mam na imię "+imieOsoby);

        } else {

            System.out.println("Cześć "+imie+", mam na imię "+imieOsoby);

        }

    }

    public static void main(String[] args) {

        Scanner skan = new Scanner(System.in);

        System.out.println("Liczba zarejestrowanych osób to "+instancje);

        Osoba osobaBezParametrow = new Osoba();

        System.out.print("Podaj id > ");
        int idPodane = skan.nextInt();

        System.out.print("Podaj imie > ");
        String imiePodane = skan.next();

        Osoba osobaZDwomaPArametrami = new Osoba(idPodane,imiePodane);

        Osoba osobaKonstruktorKopjujacy = new Osoba(osobaZDwomaPArametrami);

        osobaBezParametrow.wypisywanieImienia("Jan");
        osobaZDwomaPArametrami.wypisywanieImienia("Jan");
        osobaKonstruktorKopjujacy.wypisywanieImienia("Jan");

        System.out.println("Liczba zarejestrowanych osób to "+instancje);

    }

}
