import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'egzamin';

  kursyProgramowania = ["Programowanie w C#","Angular dla początkujących","Kurs Django"];

  imieNazwisko : string = "";
  numerKursu : number = 0;

  zapiszDoKursu(){

    if(this.numerKursu > this.kursyProgramowania.length || this.numerKursu < 0){
      
      console.log(this.imieNazwisko+" Nie ma takiego kursu");
    
    } else { 

      
      console.log(this.imieNazwisko+" "+this.kursyProgramowania[this.numerKursu]);
    
    }

  }

}
